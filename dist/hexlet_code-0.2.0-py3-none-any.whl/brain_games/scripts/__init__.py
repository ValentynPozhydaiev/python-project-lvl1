"""The package, which contains executable scripts."""
