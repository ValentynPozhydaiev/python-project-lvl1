"""The main package containing the game logic."""
