"""This package contains the game logic."""
